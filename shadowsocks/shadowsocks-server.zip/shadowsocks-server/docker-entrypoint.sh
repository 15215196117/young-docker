#!/bin/bash
/bin/shadowsocks-server -c /etc/shadowsocks.json