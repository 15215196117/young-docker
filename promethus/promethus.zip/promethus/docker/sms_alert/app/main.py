#! /usr/bin/env python2
# encoding:utf-8
import json
import Qcloud.Sms.sms as SmsSender
from flask import Flask,render_template,request
app = Flask(__name__)

@app.route('/register', methods=['POST'])#api定义，返回给短信程序
def register():
    # print request.headers
    # print request.form
    print request.json
    for i in request.json['alerts']:
        instance = i['labels']['instance']
        alertname = i['labels']['alertname']
        status = i['labels']['status']
        summary = i['annotations']['summary']
        monitor = i['labels']['monitor']

    print [instance,alertname,status,summary,monitor]
    def sms():
        # 请根据实际 appid 和 appkey 进行开发，以下只作为演示 sdk 使用
        # appid = 1400031832
        # appkey = "0820b52015ed4bdc15a75840ef4acbdc"
        #汇鑫
        appid = 1400021196
        appkey = "99f0a39df6945e36272143c465390ad1"
        phone_number1 = "18983359239"
        phone_number2 = "18623053075"
        phone_number3 = "13635343536"
        phone_numbers = [phone_number1,phone_number2,phone_number3]
        templ_id = 28393 #模板ID
        multi_sender = SmsSender.SmsMultiSender(appid, appkey)
        #短信模板 您的主机{description}，发生故障{summary},警告等级为{LABELS} 请检查相关问题！
        params = [instance,alertname,status,summary,monitor]
        result = multi_sender.send_with_param("86", phone_numbers, templ_id, params, "", "", "")
        rsp = json.loads(result)
        print result
    sms()
    return 'web'
if __name__ == '__main__':
	app.run(host='0.0.0.0',port=9092)
