#! /usr/bin/env python2
# encoding:utf-8
import json
import Qcloud.Sms.sms as SmsSender
from flask import Flask,render_template,request
app = Flask(__name__)

@app.route('/register', methods=['POST'])#api定义，返回给短信程序
def register():
    # print request.headers
    # print request.form
   # print [description,summary,labels]
    print request.json

    return 'web'
if __name__ == '__main__':
	app.run(host='127.0.0.1',port=9092)
