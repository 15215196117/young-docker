#!/bin/sh
set -e

# first arg is `-f` or `--some-option`
# or first arg is `something.conf`
#set -- consul_exporter "$@"
echo "传入参数" "$@"
exec prometheus "$@"


exec "$@"
